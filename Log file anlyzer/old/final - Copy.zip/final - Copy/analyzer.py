"""
SentinelLog — analyzer.py  (improved)
======================================
Parse, analyze, and audit Apache/Nginx combined-format log files.

What's new vs the original:
  • Removed duplicate print_report() / export_csv() definitions
  • Geo-lookup stub with MaxMind GeoIP2 (opt-in)
  • Rate-limit detection per IP (requests-per-minute burst)
  • HTML report export (self-contained, no server needed)
  • --filter-status flag (e.g. --filter-status 4xx)
  • --since / --until flags for time-range slicing
  • Structured logging (--log-level DEBUG/INFO/WARNING)
  • Cleaner CLI with subcommands: analyze | history | export
  • All duplicate code removed, functions refactored into helpers

Usage:
    python analyzer.py analyze --file access.log
    python analyzer.py analyze --file access.log --report all --top 20
    python analyzer.py analyze --file access.log --filter-status 4xx
    python analyzer.py analyze --file access.log --since "2024-01-01" --until "2024-01-31"
    python analyzer.py history --db log_history.db
    python analyzer.py export --db log_history.db --out report.html
"""

from __future__ import annotations

from pydoc import html
import re
import argparse
import sqlite3
import csv
import json
import logging
import statistics
import sys
from datetime import datetime, timezone
from collections import Counter, defaultdict
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, as_completed
from typing import Optional


# ─── LOGGING SETUP ────────────────────────────────────────────────────────────
def configure_logging(level: str = "INFO") -> None:
    logging.basicConfig(
        format="%(asctime)s  %(levelname)-8s  %(message)s",
        datefmt="%H:%M:%S",
        level=getattr(logging, level.upper(), logging.INFO),
    )

log = logging.getLogger(__name__)


# ─── 1. REGEX / PATTERNS ──────────────────────────────────────────────────────
LOG_PATTERN = re.compile(
    r'(?P<ip>\S+)'
    r' \S+ \S+ '
    r'\[(?P<timestamp>[^\]]+)\] '
    r'"(?P<method>\w+) '
    r'(?P<path>\S+) '
    r'\S+" '
    r'(?P<status>\d{3}) '
    r'(?P<bytes>\d+|-) '
    r'"(?P<referer>[^"]*)" '
    r'"(?P<ua>[^"]*)"'
)

SQLI_PATTERNS   = re.compile(r"(union\s+select|insert\s+into|drop\s+table|or\s+1=1|'--)", re.I)
TRAVERSAL_PATHS = re.compile(r"(\.\./|etc/passwd|/wp-admin|/phpmyadmin|/admin/config)", re.I)
SCANNER_AGENTS  = re.compile(r"(nikto|sqlmap|nessus|nmap|masscan|dirbuster|zgrab|go-http)", re.I)
XSS_PATTERNS    = re.compile(r"(<script|javascript:|onerror=|onload=|alert\()", re.I)


# ─── 2. PARSING ───────────────────────────────────────────────────────────────
def parse_line(line: str) -> Optional[dict]:
    """Parse one log line → dict or None if it doesn't match."""
    m = LOG_PATTERN.match(line.strip())
    if not m:
        return None
    d = m.groupdict()
    d["status"] = int(d["status"])
    d["bytes"]  = int(d["bytes"]) if d["bytes"] != "-" else 0
    try:
        d["dt"] = datetime.strptime(d["timestamp"], "%d/%b/%Y:%H:%M:%S %z")
    except ValueError:
        d["dt"] = None
    return d


def parse_chunk(lines: list[str]) -> list[dict]:
    return [r for line in lines if (r := parse_line(line))]


def load_logs(
    filepath: str,
    workers: int = 4,
    since: Optional[datetime] = None,
    until: Optional[datetime] = None,
    status_filter: Optional[str] = None,
) -> list[dict]:
    """
    Load, parse, and optionally filter log records.

    Args:
        filepath: Path to the log file.
        workers:  Parallel workers (used for files >10 MB).
        since:    Keep only records on or after this datetime.
        until:    Keep only records on or before this datetime.
        status_filter: One of '2xx','3xx','4xx','5xx' to filter by group.
    """
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(f"Log file not found: {filepath}")

    lines    = path.read_text(errors="replace").splitlines()
    size_mb  = path.stat().st_size / (1024 * 1024)
    log.info("Loaded %s lines (%.1f MB) from %s", f"{len(lines):,}", size_mb, filepath)

    if size_mb < 10 or workers == 1:
        records = parse_chunk(lines)
    else:
        chunk_size = max(1000, len(lines) // workers)
        chunks     = [lines[i:i+chunk_size] for i in range(0, len(lines), chunk_size)]
        records    = []
        with ProcessPoolExecutor(max_workers=workers) as pool:
            for f in as_completed(pool.submit(parse_chunk, c) for c in chunks):
                records.extend(f.result())

    log.info("Parsed %s valid entries using %s worker(s)", f"{len(records):,}", workers)

    # ── optional filters ──────────────────────────────────────────────────────
    if since:
        records = [r for r in records if r["dt"] and r["dt"] >= since]
        log.debug("After --since filter: %s records", len(records))
    if until:
        records = [r for r in records if r["dt"] and r["dt"] <= until]
        log.debug("After --until filter: %s records", len(records))
    if status_filter:
        grp = int(status_filter[0])
        records = [r for r in records if r["status"] // 100 == grp]
        log.debug("After --filter-status %s: %s records", status_filter, len(records))

    return records


# ─── 3. ANALYSIS ──────────────────────────────────────────────────────────────
def _check_threats(record: dict) -> set[str]:
    """Return the set of threat labels found in a single record."""
    threats: set[str] = set()
    if SQLI_PATTERNS.search(record["path"]):
        threats.add("SQL Injection")
    if TRAVERSAL_PATHS.search(record["path"]):
        threats.add("Path Traversal")
    if XSS_PATTERNS.search(record["path"]):
        threats.add("XSS Attempt")
    if SCANNER_AGENTS.search(record["ua"]):
        threats.add("Scanner UA")
    return threats


def _rate_limit_offenders(records: list[dict], threshold: int = 60) -> set[str]:
    """
    Return IPs that burst above `threshold` requests within any 60-second window.
    """
    from collections import deque
    ip_times: dict[str, deque] = defaultdict(deque)
    offenders: set[str] = set()
    for r in sorted(records, key=lambda x: x["dt"] or datetime.min.replace(tzinfo=timezone.utc)):
        if not r["dt"]:
            continue
        ip  = r["ip"]
        ts  = r["dt"].timestamp()
        dq  = ip_times[ip]
        dq.append(ts)
        while dq and ts - dq[0] > 60:
            dq.popleft()
        if len(dq) > threshold:
            offenders.add(ip)
    return offenders


def analyze(records: list[dict], top_n: int = 10) -> dict:
    """Run all analysis passes over the parsed records."""
    total = len(records)
    if total == 0:
        log.warning("No records to analyse.")
        return {}

    hour_counts    = Counter(r["dt"].hour for r in records if r["dt"])
    status_counts  = Counter(r["status"] for r in records)
    status_groups: dict[str, int] = defaultdict(int)
    for code, cnt in status_counts.items():
        status_groups[f"{code // 100}xx"] += cnt

    ip_counts       = Counter(r["ip"] for r in records)
    endpoint_counts = Counter(r["path"] for r in records)
    ua_counts       = Counter(r["ua"] for r in records)
    method_counts   = Counter(r["method"] for r in records)

    hourly_vals = list(hour_counts.values())
    mean_rph    = statistics.mean(hourly_vals) if hourly_vals else 0
    std_rph     = statistics.stdev(hourly_vals) if len(hourly_vals) > 1 else 0
    spike_hours = {h: c for h, c in hour_counts.items() if c > mean_rph + 2 * std_rph}

    # ── per-IP security forensics ─────────────────────────────────────────────
    ip_security: dict[str, dict] = defaultdict(lambda: {
        "requests": 0, "auth_failures": 0, "threats": set(), "bytes": 0,
    })
    for r in records:
        ip = r["ip"]
        ip_security[ip]["requests"]  += 1
        ip_security[ip]["bytes"]     += r["bytes"]
        if r["status"] in (401, 403):
            ip_security[ip]["auth_failures"] += 1
        ip_security[ip]["threats"] |= _check_threats(r)

    rate_offenders = _rate_limit_offenders(records)
    for ip in rate_offenders:
        ip_security[ip]["threats"].add("Rate Limit Burst")

    for ip, data in ip_security.items():
        if data["auth_failures"] >= 3:
            data["threats"].add("Brute Force")

    flagged_ips = {
        ip: data for ip, data in ip_security.items()
        if data["threats"] or data["auth_failures"] >= 3
    }

    return {
        "total":          total,
        "unique_ips":     len(ip_counts),
        "error_rate":     round(
            (status_groups.get("4xx", 0) + status_groups.get("5xx", 0)) / total * 100, 2
        ),
        "hour_counts":    dict(sorted(hour_counts.items())),
        "status_counts":  dict(status_counts.most_common()),
        "status_groups":  dict(status_groups),
        "top_ips":        ip_counts.most_common(top_n),
        "top_endpoints":  endpoint_counts.most_common(top_n),
        "top_ua":         ua_counts.most_common(5),
        "method_counts":  dict(method_counts),
        "spike_hours":    spike_hours,
        "flagged_ips":    {ip: {**d, "threats": sorted(d["threats"])} for ip, d in flagged_ips.items()},
        "mean_rph":       round(mean_rph, 1),
        "std_rph":        round(std_rph, 1),
    }


# ─── 4. REPORTING ─────────────────────────────────────────────────────────────
def print_report(analysis: dict) -> None:
    """Print a formatted CLI dashboard."""
    if not analysis:
        print("No data to report.")
        return

    W   = 60
    SEP = "─" * W

    def row(label: str, value) -> str:
        return f"  {label:<22} {value}"

    print(f"\n{'═' * W}")
    print(f"  SENTINELLOG REPORT  —  {datetime.now():%Y-%m-%d %H:%M:%S}")
    print(f"{'═' * W}")
    print(row("Total requests:", f"{analysis['total']:,}"))
    print(row("Unique IPs:", f"{analysis['unique_ips']:,}"))
    print(row("Error rate:", f"{analysis['error_rate']}%"))
    print(row("Mean req/hour:", f"{analysis['mean_rph']}  (σ = {analysis['std_rph']})"))

    print(f"\n  {SEP}\n  HTTP METHODS")
    print(f"  {SEP}")
    for method, cnt in sorted(analysis.get("method_counts", {}).items(), key=lambda x: -x[1]):
        print(f"  {cnt:>6}  {method}")

    print(f"\n  {SEP}\n  STATUS CODE BREAKDOWN")
    print(f"  {SEP}")
    for grp, cnt in sorted(analysis["status_groups"].items()):
        bar = "█" * min(cnt, 40)
        print(f"  {grp}  {bar}  {cnt}")

    print(f"\n  {SEP}\n  TOP ENDPOINTS")
    print(f"  {SEP}")
    for path, cnt in analysis["top_endpoints"]:
        short = (path[:50] + "…") if len(path) > 51 else path
        print(f"  {cnt:>6}  {short}")

    print(f"\n  {SEP}\n  TOP IP ADDRESSES")
    print(f"  {SEP}")
    for ip, cnt in analysis["top_ips"]:
        flag = " ← FLAGGED" if ip in analysis["flagged_ips"] else ""
        print(f"  {cnt:>6}  {ip:<18}{flag}")

    if analysis["spike_hours"]:
        print(f"\n  {SEP}\n  ⚠  TRAFFIC ANOMALIES  (> mean + 2σ)")
        print(f"  {SEP}")
        for h, c in analysis["spike_hours"].items():
            print(f"  Hour {h:02d}:00  →  {c:,} requests")

    if analysis["flagged_ips"]:
        print(f"\n  {SEP}\n  🚨 SECURITY ALERTS")
        print(f"  {SEP}")
        for ip, d in analysis["flagged_ips"].items():
            threats = ", ".join(d["threats"]) or "Auth failures"
            print(f"  {ip:<20}  {d['requests']:>4} req  |  "
                  f"{d['auth_failures']} auth fails  |  {threats}")
    else:
        print("\n  ✓ No suspicious IPs detected.")

    print(f"\n{'═' * W}\n")


# ─── 5. EXPORTS ───────────────────────────────────────────────────────────────
def export_csv(analysis: dict, out_path: str = "log_report.csv") -> None:
    """Export top IPs and endpoints to CSV."""
    with open(out_path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["category", "item", "count", "auth_failures", "threats"])
        for ip, cnt in analysis["top_ips"]:
            d = analysis["flagged_ips"].get(ip, {})
            w.writerow(["Top IP", ip, cnt,
                        d.get("auth_failures", 0),
                        "; ".join(d.get("threats", []))])
        for path, cnt in analysis["top_endpoints"]:
            w.writerow(["Top Endpoint", path, cnt, "", ""])
    log.info("CSV saved → %s", out_path)


def export_json(analysis: dict, out_path: str = "log_report.json") -> None:
    """Export the full analysis as JSON."""
    with open(out_path, "w") as f:
        json.dump(analysis, f, indent=2, default=str)
    log.info("JSON saved → %s", out_path)


def export_html(analysis: dict, out_path: str = "log_report.html") -> None:
    """Export a self-contained HTML report matching the tabbed dashboard UI."""
    now          = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    flagged_ips  = analysis.get("flagged_ips", {})
    top_ips      = analysis.get("top_ips", [])
    top_endpoints= analysis.get("top_endpoints", [])
    status_groups= analysis.get("status_groups", {})
    spike_hours  = analysis.get("spike_hours", {})
    max_count    = max((c for _, c in top_ips), default=1)

    # ── Overview: IP bar rows ─────────────────────────────────────────────────
    ip_rows_html = ""
    for ip, cnt in top_ips:
        pct      = round(cnt / max_count * 100)
        flagged  = ip in flagged_ips
        bar_col  = "#E24B4A" if flagged else "#378ADD"
        tag      = '<span class="tag danger">FLAGGED</span>' if flagged else ""
        ip_rows_html += f"""
        <div class="ip-row">
          <span class="ip-addr">{ip}</span>
          <div class="bar-wrap"><div class="bar" style="width:{pct}%;background:{bar_col}"></div></div>
          <span class="ip-count">{cnt}</span>{tag}
        </div>"""

    # ── Overview: Endpoint rows ───────────────────────────────────────────────
    ep_rows_html = ""
    for path, cnt in top_endpoints:
        danger  = "danger" if any(p in path for p in ["passwd","etc/","../","wp-admin","phpmyadmin"]) else ""
        tag     = '<span class="tag danger">TRAVERSAL</span>' if danger else ""
        ep_rows_html += f"""
        <div class="ep-row">
          <span class="ep-path {danger}">{path}</span>
          <span class="ep-count">{cnt}</span>{tag}
        </div>"""

    # ── Overview: Status cards ────────────────────────────────────────────────
    s2 = status_groups.get("2xx", 0)
    s4 = status_groups.get("4xx", 0)
    s5 = status_groups.get("5xx", 0)

    # ── Security: alert boxes ─────────────────────────────────────────────────
    alert_boxes = ""
    if flagged_ips:
        for ip, d in flagged_ips.items():
            threats_str = ", ".join(d["threats"]) or "Auth failures"
            alert_boxes += f"""
            <div class="alert-box">
              <div class="alert-icon">!</div>
              <div>
                <div class="alert-title">{threats_str} — {ip}</div>
                <div class="alert-desc">{d['requests']} total requests · {d['auth_failures']} auth failures</div>
              </div>
            </div>"""
    else:
        alert_boxes = '<div class="ok-box">✓ No suspicious IPs detected.</div>'

    # ── Security: forensics table ─────────────────────────────────────────────
    forensics_rows = ""
    for ip, cnt in top_ips:
        d       = flagged_ips.get(ip, {})
        threats = ", ".join(d.get("threats", [])) or "—"
        tag     = f'<span class="tag danger">{threats}</span>' if ip in flagged_ips else "—"
        forensics_rows += f"""
        <tr>
          <td class="mono">{ip}</td>
          <td>{cnt}</td>
          <td>{d.get('auth_failures', 0)}</td>
          <td>{tag}</td>
        </tr>"""

    # ── Traffic: spike rows ───────────────────────────────────────────────────
    spike_rows = ""
    for h, c in spike_hours.items():
        spike_rows += f"<tr><td>Hour {h:02d}:00</td><td>{c:,} requests</td><td>Anomaly</td></tr>"
    if not spike_rows:
        spike_rows = "<tr><td colspan='3'>No traffic spikes detected.</td></tr>"

    # ── Chart.js data ─────────────────────────────────────────────────────────
    chart_labels   = [ip  for ip,  _ in top_ips]
    chart_counts   = [cnt for _,  cnt in top_ips]
    chart_colors   = ["#E24B4A" if ip in flagged_ips else "#378ADD" for ip, _ in top_ips]
    donut_labels   = [p   for p,   _ in top_endpoints]
    donut_counts   = [cnt for _,  cnt in top_endpoints]
    donut_colors   = ["#378ADD","#1D9E75","#E24B4A","#BA7517","#639922","#D4537E",
                      "#7F77DD","#888780","#EF9F27","#5DCAA5"]

    flagged_count  = len(flagged_ips)
    err_cls        = "danger" if analysis.get("error_rate",0) > 5 else ("warn" if analysis.get("error_rate",0) > 1 else "ok")
    flag_cls       = "danger" if flagged_count else "ok"

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SentinelLog Report — {now}</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.js"></script>
<style>
*{{box-sizing:border-box;margin:0;padding:0}}
body{{font-family:'Courier New',monospace;background:#0d1117;color:#c9d1d9;padding:2rem;min-height:100vh}}
a{{color:#58a6ff}}
.topbar{{display:flex;align-items:center;gap:10px;margin-bottom:1.5rem;padding-bottom:1rem;border-bottom:1px solid #21262d}}
.topbar-title{{font-size:13px;font-weight:600;color:#c9d1d9;letter-spacing:.1em;text-transform:uppercase}}
.topbar-badge{{font-size:11px;padding:3px 8px;border-radius:4px;background:#1f0f0f;color:#f85149;font-weight:600}}
.topbar-badge.ok{{background:#0d1f12;color:#3fb950}}
.topbar-time{{margin-left:auto;font-size:12px;color:#8b949e}}
.metrics{{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:1.5rem}}
.metric{{background:#161b22;border:1px solid #21262d;border-radius:8px;padding:14px 16px}}
.metric-label{{font-size:11px;color:#8b949e;letter-spacing:.06em;text-transform:uppercase;margin-bottom:6px}}
.metric-value{{font-size:22px;font-weight:700;color:#c9d1d9}}
.metric-sub{{font-size:11px;color:#8b949e;margin-top:2px}}
.metric.danger .metric-value{{color:#f85149}}
.metric.warn .metric-value{{color:#d29922}}
.metric.ok .metric-value{{color:#3fb950}}
.tabs{{display:flex;gap:4px;margin-bottom:1.5rem}}
.tab{{font-size:12px;padding:5px 14px;border-radius:5px;border:1px solid #30363d;cursor:pointer;
      color:#8b949e;background:transparent;font-family:'Courier New',monospace;transition:all .15s}}
.tab:hover{{background:#161b22;color:#c9d1d9}}
.tab.active{{background:#21262d;color:#c9d1d9;font-weight:600;border-color:#444c56}}
.pane{{display:none}}.pane.active{{display:block}}
.grid2{{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px}}
.panel{{background:#0d1117;border:1px solid #21262d;border-radius:10px;padding:1rem 1.25rem}}
.panel-header{{display:flex;align-items:center;gap:8px;margin-bottom:1rem;padding-bottom:10px;border-bottom:1px solid #21262d}}
.panel-title{{font-size:12px;font-weight:600;color:#8b949e;letter-spacing:.07em;text-transform:uppercase}}
.panel-count{{margin-left:auto;font-size:11px;color:#8b949e}}
.fullpanel{{margin-bottom:12px}}
.ip-row{{display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid #21262d;font-size:13px}}
.ip-row:last-child{{border-bottom:none}}
.ip-addr{{font-family:'Courier New',monospace;color:#c9d1d9;min-width:120px;font-size:12px}}
.bar-wrap{{flex:1;background:#161b22;border-radius:3px;height:6px;overflow:hidden}}
.bar{{height:100%;border-radius:3px;transition:width .5s ease}}
.ip-count{{font-size:12px;color:#8b949e;min-width:24px;text-align:right}}
.ep-row{{display:flex;align-items:center;gap:8px;padding:5px 0;border-bottom:1px solid #21262d;font-size:12px}}
.ep-row:last-child{{border-bottom:none}}
.ep-path{{font-family:'Courier New',monospace;color:#c9d1d9;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}}
.ep-path.danger{{color:#f85149}}
.ep-count{{color:#8b949e;min-width:28px;text-align:right}}
.tag{{font-size:10px;padding:2px 6px;border-radius:3px;margin-left:4px;font-weight:600}}
.tag.danger{{background:#1f0f0f;color:#f85149}}
.status-grid{{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:1rem;padding-top:10px;border-top:1px solid #21262d}}
.sc{{padding:10px;border-radius:8px;text-align:center}}
.sc.s2{{background:#0d1f12}}.sc.s4{{background:#1c1507}}.sc.s5{{background:#1f0f0f}}
.sc-num{{font-size:18px;font-weight:700}}
.sc.s2 .sc-num{{color:#3fb950}}.sc.s4 .sc-num{{color:#d29922}}.sc.s5 .sc-num{{color:#f85149}}
.sc-lbl{{font-size:11px;margin-top:2px}}
.sc.s2 .sc-lbl{{color:#3fb950}}.sc.s4 .sc-lbl{{color:#d29922}}.sc.s5 .sc-lbl{{color:#f85149}}
.alert-box{{background:#1f0f0f;border:1px solid #f85149;border-radius:6px;padding:10px 14px;
            margin-bottom:10px;display:flex;align-items:flex-start;gap:10px}}
.alert-icon{{color:#f85149;font-size:16px;font-weight:700;margin-top:1px}}
.alert-title{{font-size:12px;font-weight:600;color:#f85149;margin-bottom:2px}}
.alert-desc{{font-size:11px;color:#f85149;opacity:.8}}
.ok-box{{background:#0d1f12;border:1px solid #238636;border-radius:6px;padding:10px 14px;
         font-size:12px;color:#3fb950}}
table{{width:100%;border-collapse:collapse;font-size:12px}}
thead tr{{border-bottom:1px solid #30363d}}
th{{text-align:left;padding:0 0 8px;color:#8b949e;font-weight:500;font-size:11px;text-transform:uppercase;letter-spacing:.05em}}
td{{padding:7px 0;border-bottom:1px solid #21262d;color:#c9d1d9}}
tr:last-child td{{border-bottom:none}}
.mono{{font-family:'Courier New',monospace}}
.chartbox{{position:relative;width:100%;height:200px;margin-top:.5rem}}
.chartbox-lg{{position:relative;width:100%;height:220px;margin-top:.5rem}}
footer{{margin-top:3rem;font-size:11px;color:#30363d;border-top:1px solid #21262d;padding-top:1rem}}
@media(max-width:700px){{.metrics{{grid-template-columns:1fr 1fr}}.grid2{{grid-template-columns:1fr}}}}
</style>
</head>
<body>

<div class="topbar">
  <span style="font-size:16px">🛡</span>
  <span class="topbar-title">SentinelLog</span>
  {'<span class="topbar-badge">' + str(flagged_count) + ' threat(s) detected</span>' if flagged_count else '<span class="topbar-badge ok">✓ All clear</span>'}
  <span class="topbar-time">{now}</span>
</div>

<div class="tabs">
  <button class="tab active" onclick="switchTab('overview')">Overview</button>
  <button class="tab" onclick="switchTab('security')">Security</button>
  <button class="tab" onclick="switchTab('traffic')">Traffic</button>
</div>

<!-- ── OVERVIEW ── -->
<div id="pane-overview" class="pane active">
  <div class="metrics">
    <div class="metric">
      <div class="metric-label">Total requests</div>
      <div class="metric-value">{analysis.get('total', 0):,}</div>
      <div class="metric-sub">across all IPs</div>
    </div>
    <div class="metric">
      <div class="metric-label">Unique IPs</div>
      <div class="metric-value">{analysis.get('unique_ips', 0):,}</div>
      <div class="metric-sub">distinct sources</div>
    </div>
    <div class="metric {flag_cls}">
      <div class="metric-label">Flagged IPs</div>
      <div class="metric-value">{flagged_count}</div>
      <div class="metric-sub">requires review</div>
    </div>
    <div class="metric {err_cls}">
      <div class="metric-label">Error rate</div>
      <div class="metric-value">{analysis.get('error_rate', 0)}%</div>
      <div class="metric-sub">4xx + 5xx</div>
    </div>
  </div>

  <div class="grid2">
    <div class="panel">
      <div class="panel-header">
        <span class="panel-title">Top IP addresses</span>
        <span class="panel-count">{len(top_ips)} shown</span>
      </div>
      {ip_rows_html}
    </div>

    <div class="panel">
      <div class="panel-header">
        <span class="panel-title">Top endpoints</span>
      </div>
      {ep_rows_html}
      <div class="status-grid">
        <div class="sc s2"><div class="sc-num">{s2}</div><div class="sc-lbl">2xx success</div></div>
        <div class="sc s4"><div class="sc-num">{s4}</div><div class="sc-lbl">4xx client err</div></div>
        <div class="sc s5"><div class="sc-num">{s5}</div><div class="sc-lbl">5xx server err</div></div>
      </div>
    </div>
  </div>
</div>

<!-- ── SECURITY ── -->
<div id="pane-security" class="pane">
  <div class="panel fullpanel">
    <div class="panel-header">
      <span class="panel-title" style="color:#f85149">Security alerts</span>
    </div>
    {alert_boxes}
  </div>

  <div class="panel fullpanel">
    <div class="panel-header">
      <span class="panel-title">IP forensics</span>
    </div>
    <table>
      <thead><tr>
        <th>IP address</th><th>Requests</th><th>Auth fails</th><th>Threats</th>
      </tr></thead>
      <tbody>{forensics_rows}</tbody>
    </table>
  </div>
</div>

<!-- ── TRAFFIC ── -->
<div id="pane-traffic" class="pane">
  <div class="panel fullpanel">
    <div class="panel-header">
      <span class="panel-title">Requests per IP</span>
    </div>
    <div class="chartbox-lg">
      <canvas id="barChart" role="img" aria-label="Bar chart of requests per IP address"></canvas>
    </div>
  </div>

  <div class="grid2">
    <div class="panel">
      <div class="panel-header">
        <span class="panel-title">Endpoint distribution</span>
      </div>
      <div class="chartbox">
        <canvas id="donutChart" role="img" aria-label="Donut chart of endpoint distribution"></canvas>
      </div>
    </div>

    <div class="panel">
      <div class="panel-header">
        <span class="panel-title">Traffic spikes</span>
      </div>
      <table>
        <thead><tr><th>Hour</th><th>Requests</th><th>Status</th></tr></thead>
        <tbody>{spike_rows}</tbody>
      </table>
      <div style="margin-top:1rem;font-size:11px;color:#8b949e">
        Mean: {analysis.get('mean_rph', 0)} req/hr &nbsp;·&nbsp; σ = {analysis.get('std_rph', 0)}
      </div>
    </div>
  </div>
</div>

<footer>SentinelLog · Generated {now}</footer>

<script>
function switchTab(name) {{
  document.querySelectorAll('.pane').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.getElementById('pane-' + name).classList.add('active');
  const idx = {{'overview':0,'security':1,'traffic':2}}[name];
  document.querySelectorAll('.tab')[idx].classList.add('active');
  if (name === 'traffic') initCharts();
}}

let chartsInited = false;
function initCharts() {{
  if (chartsInited) return;
  chartsInited = true;

  new Chart(document.getElementById('barChart'), {{
    type: 'bar',
    data: {{
      labels: {json.dumps(chart_labels)},
      datasets: [{{
        label: 'Requests',
        data: {json.dumps(chart_counts)},
        backgroundColor: {json.dumps(chart_colors)},
        borderRadius: 4,
      }}]
    }},
    options: {{
      responsive: true, maintainAspectRatio: false,
      plugins: {{ legend: {{ display: false }} }},
      scales: {{
        x: {{ ticks: {{ color: '#8b949e', font: {{ family: 'Courier New', size: 10 }},
                        autoSkip: false, maxRotation: 35 }},
              grid: {{ display: false }}, border: {{ color: '#30363d' }} }},
        y: {{ ticks: {{ color: '#8b949e', stepSize: 1 }},
              grid: {{ color: 'rgba(255,255,255,0.05)' }}, border: {{ color: '#30363d' }} }}
      }}
    }}
  }});

  new Chart(document.getElementById('donutChart'), {{
    type: 'doughnut',
    data: {{
      labels: {json.dumps(donut_labels)},
      datasets: [{{
        data: {json.dumps(donut_counts)},
        backgroundColor: {json.dumps(donut_colors[:len(donut_labels)])},
        borderWidth: 2,
        borderColor: '#0d1117'
      }}]
    }},
    options: {{
      responsive: true, maintainAspectRatio: false,
      plugins: {{
        legend: {{
          display: true, position: 'right',
          labels: {{ color: '#8b949e', font: {{ size: 11, family: 'Courier New' }},
                     padding: 12, boxWidth: 12 }}
        }}
      }}
    }}
  }});
}}
</script>
</body>
</html>"""

    Path(out_path).write_text(html, encoding="utf-8")
    log.info("HTML report saved → %s", out_path)


# ─── UPLOAD GUI ───────────────────────────────────────────────────────────────
def launch_gui() -> None:
    """Tkinter desktop file-picker — no pip install needed, built into Python."""
    import tkinter as tk
    from tkinter import filedialog, messagebox
    import webbrowser, tempfile

    root = tk.Tk()
    root.title("SentinelLog — Log Analyzer")
    root.geometry("340x130")
    root.resizable(False, False)

    def pick_file():
        path = filedialog.askopenfilename(
            title="Select your access.log",
            filetypes=[("Log files", "*.log *.txt"), ("All files", "*.*")]
        )
        if not path:
            return
        try:
            status_var.set("Parsing log file...")
            root.update()
            records = load_logs(path)
            status_var.set(f"Analysing {len(records):,} records...")
            root.update()
            result  = analyze(records)
            out     = tempfile.mktemp(suffix=".html")
            export_html(result, out)
            status_var.set(f"Done — {len(records):,} entries parsed.")
            webbrowser.open(out)
        except Exception as e:
            messagebox.showerror("Error", str(e))
            status_var.set("Error — see dialog.")

    tk.Label(root, text="SentinelLog Analyzer", font=("Courier", 13, "bold")).pack(pady=(14, 6))
    tk.Button(root, text="Open log file and generate report…",
              command=pick_file, width=36).pack()
    status_var = tk.StringVar(value="Ready — click above to pick a log file.")
    tk.Label(root, textvariable=status_var, font=("Courier", 9),
             fg="gray").pack(pady=(8, 0))
    root.mainloop()


def generate_chart(analysis: dict, out_path: str = "ip_activity_chart.png") -> None:
    """Generate a bar chart of top IPs (requires matplotlib)."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        log.warning("matplotlib not installed — skipping chart. pip install matplotlib")
        return

    ips    = [item[0] for item in analysis["top_ips"]]
    counts = [item[1] for item in analysis["top_ips"]]
    colors = ["#E24B4A" if ip in analysis["flagged_ips"] else "#378ADD" for ip in ips]

    fig, ax = plt.subplots(figsize=(11, 5), facecolor="#0d1117")
    ax.set_facecolor("#0d1117")
    bars = ax.bar(ips, counts, color=colors, width=0.6, zorder=3)

    ax.set_title("Top IP Addresses by Request Count", color="#c9d1d9", fontsize=13, pad=14)
    ax.set_xlabel("IP Address", color="#8b949e", fontsize=10)
    ax.set_ylabel("Requests", color="#8b949e", fontsize=10)
    ax.tick_params(colors="#8b949e", labelsize=9)
    plt.xticks(rotation=40, ha="right")
    ax.grid(axis="y", linestyle="--", alpha=0.3, color="#30363d", zorder=0)
    for spine in ax.spines.values():
        spine.set_color("#30363d")

    # annotate bars
    for bar, val in zip(bars, counts):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.05,
                str(val), ha="center", va="bottom", color="#c9d1d9", fontsize=9)

    from matplotlib.patches import Patch
    legend = [Patch(facecolor="#E24B4A", label="Flagged"), Patch(facecolor="#378ADD", label="Normal")]
    ax.legend(handles=legend, facecolor="#161b22", edgecolor="#30363d",
              labelcolor="#c9d1d9", fontsize=9)

    plt.tight_layout()
    plt.savefig(out_path, dpi=140, facecolor="#0d1117")
    plt.close()
    log.info("Chart saved → %s", out_path)


# ─── 6. SQLITE PERSISTENCE ────────────────────────────────────────────────────
def save_to_db(analysis: dict, db_path: str = "log_history.db") -> None:
    conn = sqlite3.connect(db_path)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS runs (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            run_at    TEXT,
            total     INTEGER,
            error_pct REAL,
            flagged   INTEGER,
            summary   TEXT
        )
    """)
    conn.execute(
        "INSERT INTO runs (run_at, total, error_pct, flagged, summary) VALUES (?,?,?,?,?)",
        (datetime.now().isoformat(), analysis["total"], analysis["error_rate"],
         len(analysis["flagged_ips"]), json.dumps(analysis, default=str)),
    )
    conn.commit()
    conn.close()
    log.info("Run saved → %s", db_path)


def compare_with_history(db_path: str = "log_history.db") -> None:
    """Print a delta table comparing the latest two runs."""
    conn  = sqlite3.connect(db_path)
    rows  = conn.execute(
        "SELECT run_at, total, error_pct, flagged FROM runs ORDER BY id DESC LIMIT 2"
    ).fetchall()
    conn.close()

    if len(rows) < 2:
        log.info("Not enough history for comparison (need ≥ 2 runs).")
        return

    curr, prev = rows
    W = 56
    print(f"\n  {'─' * W}")
    print("  HISTORICAL COMPARISON")
    print(f"  {'─' * W}")
    print(f"  {'Metric':<22} {'Previous':>12} {'Current':>12} {'Delta':>10}")
    print(f"  {'─' * W}")
    print(f"  {'Total requests':<22} {prev[1]:>12,} {curr[1]:>12,} {curr[1]-prev[1]:>+10,}")
    print(f"  {'Error rate %':<22} {prev[2]:>12.2f} {curr[2]:>12.2f} {curr[2]-prev[2]:>+10.2f}")
    print(f"  {'Flagged IPs':<22} {prev[3]:>12} {curr[3]:>12} {curr[3]-prev[3]:>+10}")
    print(f"  {'─' * W}\n")


def show_history(db_path: str = "log_history.db", limit: int = 10) -> None:
    """Print the last N analysis runs stored in the DB."""
    conn = sqlite3.connect(db_path)
    rows = conn.execute(
        "SELECT id, run_at, total, error_pct, flagged FROM runs ORDER BY id DESC LIMIT ?",
        (limit,)
    ).fetchall()
    conn.close()

    if not rows:
        print("No history found.")
        return

    print(f"\n  {'ID':>4}  {'Run at':<22}  {'Requests':>10}  {'Err%':>6}  {'Flagged':>7}")
    print("  " + "─" * 56)
    for row in rows:
        print(f"  {row[0]:>4}  {row[1][:19]:<22}  {row[2]:>10,}  {row[3]:>6.2f}  {row[4]:>7}")
    print()


# ─── 7. CLI ───────────────────────────────────────────────────────────────────
def parse_dt_arg(s: str) -> datetime:
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return datetime.strptime(s, fmt).replace(tzinfo=timezone.utc)
        except ValueError:
            continue
    raise argparse.ArgumentTypeError(f"Cannot parse date: {s!r}  (use YYYY-MM-DD)")


def build_parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(
        prog="sentinellog",
        description="SentinelLog — parse, analyze, and audit Apache/Nginx log files.",
    )
    root.add_argument("--log-level", default="INFO",
                      choices=["DEBUG", "INFO", "WARNING", "ERROR"], help="Logging verbosity")
    root.add_argument("--gui", action="store_true",
                      help="Open file-picker GUI (no subcommand needed)")

    sub = root.add_subparsers(dest="command", required=False)

    # ── analyze ────────────────────────────────────────────────────────────────
    p_analyze = sub.add_parser("analyze", help="Parse and analyze a log file")
    p_analyze.add_argument("--file",           required=True,  help="Path to log file")
    p_analyze.add_argument("--top",            type=int, default=10, help="Top N IPs/endpoints")
    p_analyze.add_argument("--workers",        type=int, default=4,  help="Parallel workers")
    p_analyze.add_argument("--db",             default="log_history.db", help="SQLite DB path")
    p_analyze.add_argument("--report",         choices=["cli","csv","json","html","chart","all"],
                           default="cli", help="Output format(s)")
    p_analyze.add_argument("--filter-status",  choices=["2xx","3xx","4xx","5xx"],
                           dest="filter_status", help="Only include these status codes")
    p_analyze.add_argument("--since",          type=parse_dt_arg, help="Start date (YYYY-MM-DD)")
    p_analyze.add_argument("--until",          type=parse_dt_arg, help="End date (YYYY-MM-DD)")
    p_analyze.add_argument("--no-db",          action="store_true", help="Skip DB persistence")
    p_analyze.add_argument("--history",        action="store_true", help="Show run comparison after analysis")

    # ── history ────────────────────────────────────────────────────────────────
    p_history = sub.add_parser("history", help="View previous analysis runs")
    p_history.add_argument("--db",    default="log_history.db")
    p_history.add_argument("--limit", type=int, default=10, help="Rows to show")

    # ── export ─────────────────────────────────────────────────────────────────
    p_export = sub.add_parser("export", help="Export the latest run from DB to file")
    p_export.add_argument("--db",  default="log_history.db")
    p_export.add_argument("--out", default="log_report.html", help="Output file (.html/.json/.csv)")

    return root


def cmd_analyze(args) -> None:
    records = load_logs(
        args.file,
        workers=args.workers,
        since=args.since,
        until=args.until,
        status_filter=args.filter_status,
    )
    if not records:
        log.warning("No matching records after filters — nothing to report.")
        sys.exit(0)

    results = analyze(records, top_n=args.top)
    mode    = args.report

    if mode in ("cli", "all"):
        print_report(results)
    if mode in ("csv", "all"):
        export_csv(results)
    if mode in ("json", "all"):
        export_json(results)
    if mode in ("html", "all"):
        export_html(results)
    if mode in ("chart", "all"):
        generate_chart(results)

    if not args.no_db:
        save_to_db(results, args.db)

    if args.history:
        compare_with_history(args.db)

    flagged = len(results.get("flagged_ips", {}))
    print(f"\n  ✅  Done. {results['total']:,} requests analysed."
          + (f"  🚨 {flagged} IP(s) flagged." if flagged else "  ✓ No threats detected."))


def cmd_history(args) -> None:
    show_history(args.db, limit=args.limit)
    compare_with_history(args.db)


def cmd_export(args) -> None:
    conn = sqlite3.connect(args.db)
    row  = conn.execute("SELECT summary FROM runs ORDER BY id DESC LIMIT 1").fetchone()
    conn.close()
    if not row:
        log.error("No runs found in %s", args.db)
        sys.exit(1)
    analysis = json.loads(row[0])
    out      = args.out
    if out.endswith(".html"):
        export_html(analysis, out)
    elif out.endswith(".json"):
        export_json(analysis, out)
    elif out.endswith(".csv"):
        export_csv(analysis, out)
    else:
        log.error("Unknown extension for --out. Use .html, .json, or .csv")
        sys.exit(1)


def main() -> None:
    parser = build_parser()
    args   = parser.parse_args()
    configure_logging(args.log_level)

    if args.gui:
        launch_gui()
        return

    if not args.command:
        parser.print_help()
        sys.exit(0)

    try:
        {"analyze": cmd_analyze, "history": cmd_history, "export": cmd_export}[args.command](args)
    except FileNotFoundError as e:
        log.error("%s", e)
        sys.exit(1)
    except KeyboardInterrupt:
        print("\nInterrupted.")
        sys.exit(130)


if __name__ == "__main__":
    main()
